<?php

/**
 * Plugin Name:       Block Preview
 * Description:       View block previews in an iFrame.
 * Requires at least: 6.1
 * Requires PHP:      7.0
 * Version:           1.0.4
 * Author:            The Paddock People
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       block-preview
 *
 * @package block-preview
 */

add_action(
    'enqueue_block_editor_assets',
    function () {
        if (\file_exists(plugin_dir_path(__FILE__) . 'build/index.asset.php')) {
            $assets = include_once plugin_dir_path(__FILE__) . 'build/index.asset.php';
            wp_enqueue_script(
                'pp-block-preview', // Handle.
                plugin_dir_url(__FILE__) . "/build/index.js",
                $assets['dependencies'],
                $assets['version'],
                true
            );

            wp_enqueue_style(
                'pp-block-preview',
                plugin_dir_url(__FILE__) . "/build/index.css",
                false,
                $assets['version'],
            );
        }
    }
);

add_filter(
    'pre_render_block',
    function ($empty, $parsed_block, $parent_block) {
        global $blockIndex;

        if ($parent_block || empty($parsed_block['blockName'] ?? '')) {
            return $empty;
        }

        if ($blockIndex === null) {
            $blockIndex = 0;
        } else {
            $blockIndex++;
        }

        return $empty;
    },
    3,
    3
);

add_filter(
    'render_block',
    function ($block_content, $parsed_block, $block) {
        global $blockIndex;

        if (empty($parsed_block['blockName'] ?? '')) {
            return $block_content;
        }

        // I hate this, but its the only way I can think of to allow anchors here
        return '<div id="block-' . $blockIndex . '" style="display: block; position: relative; top: -180px; visibility: hidden;"></div>' . $block_content;
    },
    3,
    3
);
