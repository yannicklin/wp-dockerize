import { registerPlugin } from '@wordpress/plugins';
import { PluginMoreMenuItem } from '@wordpress/edit-post';
import { useState } from '@wordpress/element';
import './index.scss';

const MenuItemBlockBoundary = () => {
    const localStorageKey = 'pp-block-boundary';
    const value = localStorage.getItem(localStorageKey)
    const [ isChecked, setChecked ] = useState(JSON.parse(value) || false);

    const updateChecked = (value) => {
        localStorage.setItem(localStorageKey, value);
        setChecked(value)
    }

    if(isChecked) {
        document.body.classList.add('pp-block-boundary');
    } else {
        document.body.classList.remove('pp-block-boundary');
    }

    return (
        <PluginMoreMenuItem
            icon={isChecked ? 'saved' : null}
            title="Block Boundary Markers"
            onClick={() => {
                updateChecked(!isChecked)
                }}
        >
            { isChecked ? 'Block Boundary Markers (Enabled)' : 'Block Boundary Markers (Disabled)'}
        </PluginMoreMenuItem>
    )
}

registerPlugin(
    'block-settings-menu-group-preview', {
        render: MenuItemBlockBoundary,
    } 
);