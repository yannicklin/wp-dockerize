import { registerPlugin } from '@wordpress/plugins';
import { PluginBlockSettingsMenuItem } from '@wordpress/edit-post';
import { Button, Modal } from '@wordpress/components';
import { useState } from '@wordpress/element';
import './index.scss';
const MenuGroupPreview = () => {

    const [isOpen, setOpen] = useState(false);
    const [previewLink, setPreviewLink] = useState(false);
    const openModal = () => setOpen(true);
    const closeModal = () => setOpen(false);

    return (
        <div>
            <PluginBlockSettingsMenuItem
                icon="smiley"
                label="Preview Block"
                onClick={() => {
                    const {
                        isPostLocked,
                        isEditedPostAutosaveable,
                        getEditedPostAttribute,
                        getEditedPostPreviewLink,
                        getSelectedBlockClientId,
                        getBlockIndex,
                        getBlock
                    } = wp.data.select('core/editor');


                    const blockIndex = getBlockIndex(getSelectedBlockClientId());

                    const isDraft = ['draft', 'auto-draft'].indexOf(getEditedPostAttribute('status')) !== -1;

                    if (!isEditedPostAutosaveable() || isPostLocked()) {
                        alert(`The post is locked or an auto save is available, either remove the autosave or unlock the post to preview.`);
                        return;
                    }

                    const previewUrl = `${getEditedPostPreviewLink()}#block-${blockIndex}`;
                    setPreviewLink(previewUrl)

                    if (isDraft) {
                        wp.data.dispatch('core/editor').savePost(
                            {
                                isPreview: true
                            }
                        ).then(
                            () => {
                                openModal();
                            }
                        );

                    } else {
                        wp.data.dispatch('core/editor').autosave(
                            {
                                isPreview: true
                            }
                        ).then(
                            () => {
                                openModal();
                            }
                        );
                    }
                    }}
            />
            {isOpen && (
                <Modal title="Page Preview" onRequestClose={ closeModal } className={'pp-preview-modal'}>
                    <iframe src={previewLink} width="100%" height="100%"></iframe>
                </Modal>
            )}
        </div>
    )
}

registerPlugin(
    'pp-menu-group-preview', {
        render: MenuGroupPreview,
    } 
);