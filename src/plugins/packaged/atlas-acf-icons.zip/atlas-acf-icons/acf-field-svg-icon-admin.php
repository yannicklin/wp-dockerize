<?php

namespace Atlas\IconSelector;

use Atlas\IconSelector\Fields\acf_field_svg_icon_56;

class acf_field_svg_icon_admin
{

    public function __construct()
    {
        add_action('admin_menu', [$this, 'register_menu'], 20);
        add_action('init', [$this, 'override_acf_page_title']);
    }

    public function override_acf_page_title()
    {
        if (isset($_GET['page']) && $_GET['page'] == 'acf-clear-icon-cache') {
            global $acf_page_title;

            $acf_page_title = "Clear Icon Cache";
        }
    }

    public function register_menu()
    {
        if (!function_exists('acf_get_setting')) {
            return;
        }
        add_submenu_page(
            'edit.php?post_type=acf-field-group',
            'Clear Icon Cache',
            'Clear Icon Cache',
            acf_get_setting('capability'),
            'acf-clear-icon-cache',
            [$this, 'view']
        );
    }

    public function view()
    {
        delete_transient(ACF_SVG_ICON_CACHE_KEY);
        $available_icons = (new acf_field_svg_icon_56)->get_all_svg_files();
        ?>

        <div class="wrap" id="acf-admin-tools">

            <h1>Clear Icon Cache</h1>
            <div class="acf-meta-box-wrap">
                <p>Transient deleted!</p>
                <?php if (empty($available_icons)) : ?>
                    <p>No available icons found</p>
                <?php else: ?>
                    <p>Active icons:</p>
                    <ul>
                        <?php foreach ($available_icons as $icon): ?>
                            <li>
                                <img src="<?php echo $icon['file_url'] ?>"
                                     alt="<?php echo $icon['id'] ?>"/> <?php echo $icon['id'] ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>

        </div>
        <?php
    }
}
