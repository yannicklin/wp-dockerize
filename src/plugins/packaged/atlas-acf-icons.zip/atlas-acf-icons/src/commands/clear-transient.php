<?php

namespace Atlas\IconSelector\Commands;

class ClearTransient
{
    public function __invoke($args)
    {
        delete_transient(ACF_SVG_ICON_CACHE_KEY);

        \WP_CLI::log('Transient cleared!');

    }
}

\WP_CLI::add_command('atlas:icons:clear', ClearTransient::class);
