<?php
/*
 Plugin Name: Atlas ACF Icons
 Version: 1.0.4
 Plugin URI: https://atlas.paddockpeople.com.au/
 Description: Add an ACF SVG icon selector.
 Author: The paddock People
 Author URI: https://www.paddockpeople.com.au
 Domain Path: languages
 Text Domain: acf-svg-icon

 ----

 Copyright 2017 BE API Technical team (human@beapi.fr)

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

namespace Atlas\IconSelector;

if (!defined('ABSPATH')) {
    die();
}

define('ACF_SVG_ICON_VER', '3.0.0');
define('ACF_SVG_ICON_URL', plugin_dir_url(__FILE__));
define('ACF_SVG_ICON_DIR', plugin_dir_path(__FILE__));
define('ACF_SVG_ICON_CACHE_KEY', 'acf_svg_icon_files');

require_once sprintf('%sacf-field-svg-icon-plugin.php', ACF_SVG_ICON_DIR);
require_once sprintf('%sacf-field-svg-icon-admin.php', ACF_SVG_ICON_DIR);

/**
 * Init plugin.
 *
 * @since 1.0.0
 */
function acf_field_svg_icon()
{
    new acf_field_svg_icon_plugin();
    new acf_field_svg_icon_admin();
}

if (class_exists('WP_CLI')) {
    include_once sprintf('%ssrc/commands/clear-transient.php', ACF_SVG_ICON_DIR);
}
add_action('plugins_loaded', __NAMESPACE__ . '\\acf_field_svg_icon');

